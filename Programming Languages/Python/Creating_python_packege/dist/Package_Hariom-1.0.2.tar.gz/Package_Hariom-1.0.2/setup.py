from setuptools import setup
setup(name="Package_Hariom",
      version="1.0.2",
      description="This is a python package spatially for car show rooms.",
      long_description="This package is now available for only Audi, BMW and Nissan cars.",
      author="hariom Singh Rajput",
      Email="Hariommewada1001@mycars.com",
      packages=["Package_Hariom"],
      install_requires=[])